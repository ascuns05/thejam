<?php
if(isset($_POST["name"])):
	if($_POST["name"]):
		$e1=null;
		$name=trim($_POST["name"]);
		$name=strip_tags($name);
		
		$phone=trim($_POST["phone"]);
		$phone=strip_tags($phone);
        
        $tarif=trim($_POST["tarif"]);
		$tarif=strip_tags($tarif);
		
		if($e1==null):
			// здесь мы делаем с данными, то что нам нужно
			// записываем в базу или файл
			// или отправляем их на почту
			$mail="request@thejam.xyz"; // e-mail куда уйдет письмо
			$title="Завка с Лендоса"; // заголовок(тема) письма
			//конвертируем 
			$title=iconv("utf-8","windows-1251",$title);
			$title=convert_cyr_string($title, "w", "k");
		
			$message="<html><head></head><body><b>Имя:</b> $name<br>";
			// ссылка dialer
            $message.="<b>Телефон:</b> <a href='tel:$phone'>$phone</a><br>"; 
            $message.="<b>Выбранный тариф:</b> $tarif";
			$message.="</body></html>"; 
			//конвертируем 
			$message=iconv("utf-8","windows-1251",$message);
			$message=convert_cyr_string($message, "w", "k");
			
			$headers="MIME-Version: 1.0\r\n";
			$headers.="Content-Type: text/html; charset=koi8-r\r\n";
			mail($mail, $title, $message, $headers); // отправляем
            ?>
            <?php
        endif;
	endif;
endif;
?>